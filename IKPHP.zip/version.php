<?php
/* 当前IKPHP程序版本 */
define('IKPHP_VERSION', '1.5');
define('IKPHP_RELEASE', '2013-02-23');
define('IKPHP_YEAR', '2012-2050');
define('IKPHP_SITENAME', 'IKPHP');
define('IKPHP_SITEURL', 'http://www.ikphp.com');
define('IKPHP_EMAIL','160780470@qq.com');
