<?php 
return array (
	'BASIC_THEME' => 'default',
	'DEFAULT_THEME' => 'default',
	'SHOW_RUN_TIME'    => true, // 运行时间显示
	'SHOW_ADV_TIME'    => true, // 显示详细的运行时间
);