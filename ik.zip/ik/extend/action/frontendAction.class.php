<?php
/**
 * 前台控制器基类
 *
 * @author 小麦
 */
class frontendAction extends baseAction {

    protected $visitor = null;
    
    public function _initialize() {
        parent::_initialize();
        
    }
    
  
}