<?php
/**
 * 控制器基类
 *
 * @author 小麦
 */
class baseAction extends Action
{
    protected function _initialize() {
    	//消除所有的magic_quotes_gpc转义
    	//初始化网站配置
    	
        if (false === $setting = F('setting')) {
            $setting = D('setting')->setting_cache();
        }
        C($setting);
       
      
    }
    
 
}