<?php

// 行为插件
return array(

    'view_filter' => array(
        'content_replace', //路径替换
    ),


);