<?php
return array(

	'LOAD_EXT_CONFIG' => 'db,url', //扩展配置


);
?>