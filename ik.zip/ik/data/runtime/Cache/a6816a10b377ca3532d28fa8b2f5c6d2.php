<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
<style>__THEME_CSS__</style>
</head>

<body>
 <a href="<?php echo U('group/index/index');?>">小组</a>
</body>
</html>