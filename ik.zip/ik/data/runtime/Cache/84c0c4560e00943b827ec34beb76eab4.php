<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
<style>__THEME_CSS__</style>
</head>

<body>
<a href="<?php echo U('public/index/user');?>">主页</a>
abc next
</body>
</html>