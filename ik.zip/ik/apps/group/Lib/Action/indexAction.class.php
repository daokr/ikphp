<?php
// 本类由系统自动生成，仅供测试用途
class indexAction extends frontendAction {
    public function index(){

    	$this->display();
    }
}