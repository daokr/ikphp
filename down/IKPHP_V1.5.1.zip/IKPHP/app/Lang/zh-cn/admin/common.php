<?php

return array (
		'yes' => '是',
		'no' => '否',
		'open' => '开启',
		'close' => '关闭',
		'admin_not_exist' => '帐号不存在或已禁用！',
		'password_error' => '密码错误',
		'login_success' => '登陆成功',
		'logout_success' => '退出成功',
		'operation_success' => '操作成功',
		'operation_failure' => '操作失败',
);
