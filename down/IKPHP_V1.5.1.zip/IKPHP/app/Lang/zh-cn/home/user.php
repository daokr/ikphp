<?php

return array (
		'user_regist_tit' => '用户注册',
		'captcha_failed' => '验证码输入有误，请重新输入！',
		'inconsistent_password' => '两次输入的密码不一致！',
		'username_exists' => '这名号太热门了，被别人抢走啦，换一个吧',
		'email_exists' => '该email已被注册',
		'please_input' => '请输入',
		'username' => '用户名',
		'email_not_null' => 'Email不能为空！',
		'password_not_null' => '密码不能为空！',
		'auth_failed' => '密码错误，请重试或联系站长！',
		'username_not_null' => '不管做什么都需要有一个名号吧^_^!',
		'username_length_tip' => '名字长度必须在 2 到 14 汉字之间!',
		'edit_success' => '修改成功！',
		'edit_failed' => '修改失败！',
		'user_info' => '基本资料',
		'user_area' => '常居地',
);
