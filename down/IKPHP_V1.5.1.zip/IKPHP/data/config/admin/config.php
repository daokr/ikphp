<?php
return array(
    'URL_MODEL' => '0',
    'URL_ROUTER_ON' => false,
);