<?php
return array (
  'DB_SQL' => 'mysql',
  'DB_HOST' => 'localhost',
  'DB_NAME' => 'joomla',
  'DB_USER' => 'root',
  'DB_PWD' => '',
  'DB_PORT' => '3306',
  'DB_PREFIX' => 'ik_',
);