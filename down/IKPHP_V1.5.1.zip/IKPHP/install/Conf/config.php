<?php
return array (
		'DEFAULT_MODULE' => 'index', // 默认控制器
		'URL_MODEL' => '0',
		'OUTPUT_ENCODE' => false,
		'APP_DEBUG' => true,
		'DB_FIELD_CACHE' => false,
		'HTML_CACHE_ON' => false,
		'URL_CASE_INSENSITIVE' => false,
);
?>