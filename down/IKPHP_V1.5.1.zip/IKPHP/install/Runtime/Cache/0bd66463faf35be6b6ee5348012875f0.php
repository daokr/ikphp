<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo L('page_title');?></title>
<link rel="stylesheet" type="text/css" href="__TMPL__public/style.css" />
<script type="text/javascript" src="__TMPL__public/jquery.js"></script>
</head>
<body>
<!--header-->
<div class="header">
<div class="head">
<div class="logo"><a href="index.php"><img src="__TMPL__public/logo.gif" alt="<?php echo L('page_title');?>" /></a></div>
<div class="menu"><?php echo L('page_title');?> <?php echo ($IK_VERSION); ?>
</div>
</div>
</div>

<style>
.main{
    background: none repeat scroll 0 0 #FFFFFF;
    border: 1px solid #DFDFDF;
    border-radius: 11px 11px 11px 11px;
    color: #333333;
    font-family: "Lucida Grande",Verdana,Arial,"Bitstream Vera Sans",sans-serif;
    margin: 2em auto;
    padding: 1em 2em;
    width: 700px;
}
p, li, dd, dt {
    font-size: 12px;
    line-height: 18px;
    padding-bottom: 2px;
}
.step {
    margin: 20px 0 15px;
}
.step, th {
    padding: 0;
    text-align: left;
}
.submit input, .button, .button-secondary {
    -moz-box-sizing: content-box;
    border: 1px solid #BBBBBB;
    border-radius: 15px 15px 15px 15px;
    color: #464646;
    cursor: pointer;
    font-family: "Lucida Grande",Verdana,Arial,"Bitstream Vera Sans",sans-serif;
    font-size: 14px !important;
    line-height: 16px;
    padding: 6px 12px;
    text-decoration: none;
}
.button:hover, .button-secondary:hover, .submit input:hover {
    border-color: #666666;
    color: #000000;
}
.button, .submit input, .button-secondary {
    background:#F2F2F2;
}
.button:active, .submit input:active, .button-secondary:active {
    background: #EEEEEE;
}

.form-table {
    border-collapse: collapse;
    margin-top: 1em;
    width: 100%;
}
.form-table td {
    border-bottom: 8px solid #FFFFFF;
    font-size: 12px;
    margin-bottom: 9px;
    padding: 10px;
}
.form-table td.w1{
	width:200px;
}
.form-table th {
    border-bottom: 8px solid #FFFFFF;
    font-size: 13px;
    padding: 16px 10px 10px;
    text-align: left;
    vertical-align: top;
    width: 130px;
}
.form-table tr {
    background: none repeat scroll 0 0 #F3F3F3;
}
.form-table code {
    font-size: 18px;
    line-height: 18px;
}
.form-table p {
    font-size: 11px;
    margin: 4px 0 0;
}
.form-table input {
    font-size: 15px;
    line-height: 20px;
    padding: 2px;
}
.form-table th p {
    font-weight: normal;
}
#error-page {
    margin-top: 50px;
}
#error-page p {
    font-size: 12px;
    line-height: 18px;
    margin: 25px 0 20px;
}
#error-page code, .code {
    font-family: Consolas,Monaco,Courier,monospace;
}
#pass-strength-result {
    background-color: #EEEEEE;
    border-color: #DDDDDD !important;
    border-style: solid;
    border-width: 1px;
    display: none;
    margin: 5px 5px 5px 1px;
    padding: 5px;
    text-align: center;
    width: 200px;
}
#pass-strength-result.bad {
    background-color: #FFB78C;
    border-color: #FF853C !important;
}
#pass-strength-result.good {
    background-color: #FFEC8B;
    border-color: #FFCC00 !important;
}
#pass-strength-result.short {
    background-color: #FFA0A0;
    border-color: #F04040 !important;
}
#pass-strength-result.strong {
    background-color: #C3FF88;
    border-color: #8DFF1C !important;
}
.error_msg {
    background-color: #FFFFE0;
    border: 1px solid #E6DB55;
    margin: 5px 0 15px;
    padding: 0.3em 0.6em;
}
.field_tip{}
.field_tip input{ margin-top:4px; float:left; margin-left:10px}
</style>

<!--main-->
<div class="midder">

<div class="main">

<form action="<?php echo U('next');?>" method="post">
	<p>请在下方输入数据库相关信息。若您不清楚，请咨询主机提供商。</p>
	<?php if(isset($error_msg)): ?><div class="error_msg"><?php echo ($error_msg); ?></div><?php endif; ?>
	<table class="form-table">
		<tbody><tr>
			<th scope="row"><label for="dbname">数据库名</label></th>
			<td class="w1"><input type="text" value="<?php echo ($dbname); ?>" size="25" id="dbname" name="dbname"></td>
			<td><span class="field_tip"><?php echo ($database_name_tip); ?></span></td>
		</tr>
		<tr>
			<th scope="row"><label for="dbuser">用户名</label></th>
			<td><input type="text" value="<?php echo ($dbuser); ?>" size="25" id="dbuser" name="dbuser"></td>
			<td>您的 MySQL 用户名</td>
		</tr>
		<tr>
			<th scope="row"><label for="dbpwd">密码</label></th>
			<td><input type="text" value="<?php echo ($dbpwd); ?>" size="25" id="dbpwd" name="dbpwd"></td>
			<td>... 以及 MySQL 密码。</td>
		</tr>
		<tr>
			<th scope="row"><label for="dbhost">数据库主机</label></th>
			<td><input type="text" value="<?php echo ($dbhost); ?>" size="25" id="dbhost" name="dbhost"></td>
			<td>通常情况下，应填写 <code>localhost</code>，若测试连接失败，请联系主机提供商咨询。</td>
		</tr>
		
		<tr>
			<th scope="row"><label for="dbport">端口</label></th>
			<td><input type="text" value="<?php echo ($dbport); ?>" size="25" id="dbport" name="dbport"></td>
			<td>默认3306</td>
		</tr>
		
		<tr>
			<th scope="row"><label for="prefix">表名前缀</label></th>
			<td><input type="text" size="25" value="<?php echo ($dbprefix); ?>" id="dbprefix" name="dbprefix"></td>
			<td>若您希望在一个数据库中存放多个 <?php echo L('name');?> 的数据，请修改本项以做区分。</td>
		</tr>
	</tbody></table>
	
<p>请在下面输入网站信息</p>

	<table class="form-table">
		<tbody>
		<tr>
			<th scope="row"><label for="site_title">网站标题：</label></th>
			<td class="w1"><input type="text" value="<?php echo ($site_title); ?>" size="25" name="site_title"></td>
			<td>也是你的网站名称</td>
		</tr>
		
		<tr>
			<th scope="row"><label for="site_subtitle">网站副标题：</label></th>
			<td><input type="text" value="<?php echo ($site_subtitle); ?>" size="25" name="site_subtitle"></td>
			<td>用于首页副标题，紧跟网站标题之后</td>
		</tr>
		
		<tr>
			<th scope="row"><label for="site_url">网站URL：</label></th>
			<td><input type="text" value="<?php echo ($site_url); ?>" size="25" name="site_url"></td>
			<td>正确填写，http://开头，/结尾</td>
		</tr>
		
	</tbody>
	</table>

<p>请在下面输入管理员信息</p>

	<table class="form-table">
		<tbody>
		<tr>
			<th scope="row"><label for="email">登录Email：</label></th>
			<td class="w1"><input type="text" value="<?php echo ($admin_email); ?>" size="25" name="admin_email"></td>
			<td>你用来登录和最高管理的账户</td>
		</tr>
		
		<tr>
			<th scope="row"><label for="password">登录密码：</label></th>
			<td><input type="text" value="<?php echo ($admin_password); ?>" size="25" name="admin_password"></td>
			<td>您的登录密码</td>
		</tr>
		
		<tr>
			<th scope="row"><label for="admin_username">用户名：</label></th>
			<td><input type="text" value="<?php echo ($admin_username); ?>" size="25" name="admin_username"></td>
			<td>你的用户名</td>
		</tr>
		
	</tbody>
	</table>
	
<p>选择数据库链接方式</p>
	<table class="form-table">
		<tbody>
		<tr>
			<th scope="row"><label for="sql">选择连接方式：</label></th>
			<td class="w1"><select name="sql">
			<option value="mysql">MySQL</option>
			</select></td>
			<td></td>
		</tr>
		
	</tbody>
	</table>
	
		<p class="step">
        <input type="button" class="button"  onclick="javascript:history.go(-1);return false;" href="javascript:;" value="上一步">&nbsp;&nbsp;&nbsp;
        <input type="submit" class="button" value="确认安装" name="submit">
        </p>
</form>

</div>

</div>

<!--footer-->
<div class="footer">Powered by <a href="<?php echo (IKPHP_SITEURL); ?>" target="_blank"><?php echo (IKPHP_SITENAME); ?></a>&nbsp;版本 <?php echo (IKPHP_VERSION); ?> &copy; <?php echo (IKPHP_YEAR); ?>
</div>
</body>
</html>